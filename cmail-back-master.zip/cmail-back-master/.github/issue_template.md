## Pré-criar uma issue

- [ ] Verifique se ela já não existe em outra issue, ou está prevista em nosso board: https://github.com/omariosouto/cmail-back/projects/1
- [ ] ...

## Descrição

Insira aqui uma breve descrição com o que deseja de funcionalidade, melhoria ou bug encontrado.

## Screenshots

Caso tenha encontrado um bug ou algo que seja possível mostrar via imagens utilize essa seção.

